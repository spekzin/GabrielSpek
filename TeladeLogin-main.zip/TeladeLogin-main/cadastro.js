document.getElementById("btnCadastro").addEventListener("click", function () {
    const nome = document.getElementById("Nome").value;
    const email = document.getElementById("email").value;
    const senha = document.getElementById("senha").value;
    const CPF = document.getElementById("CPF").value;
    const Celular = document.getElementById("Celular").value;
    const aviso = document.getElementById("aviso");

    if (email === "" || senha === "" || senha === "" || CPF === "" || aviso === "") {
        aviso.style.display = "block"
    } else {
        window.location.href = 'index.html';
    }
});

document.getElementById("btnEntrar").addEventListener("click", function () {
    const email = document.getElementById("email").value;
    const senha = document.getElementById("senha").value;
    const aviso = document.getElementById("aviso");

    if (email === "" || senha === "") {
        aviso.style.display = "block"
    } else {
        window.location.href = 'plataformaFinal.html';
    }

});
document.getElementById("cadastro").addEventListener("click", function () {
    window.location.href = ('cadastro.html')

});
document.getElementById("esqueceuSenha").addEventListener("click", function () {
    window.location.href = ('esqueceuSenha.html')

});
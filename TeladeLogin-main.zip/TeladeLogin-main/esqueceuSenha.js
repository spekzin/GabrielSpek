document.getElementById("btnEnviar").addEventListener("click", function () {
    const email = document.getElementById("email").value;
    const aviso = document.getElementById("aviso");
    const alert = document.getElementById("alert");

    if (email != "") {
        alert.style.display = "none"; //faz esconder a mensagem qnd a oura aparecer
        aviso.style.display = "block"; //aparece
        setTimeout(function(){
            window.location.href = 'index.html'}, 2000);

    } else if (email === ""){
        alert.style.display = "block"; //mostra
        
    }});



document.addEventListener('DOMContentLoaded', function () {
    let visor = document.querySelector('.visor');
    let operando1 = '';
    let operando2 = '';
    let operador = '';
    let resultado = 0; //pra começar no visor com 0

    function limparVisor() {
        visor.textContent = '0';
        operando1 = '';
        operando2 = '';
        operador = '';
        resultado = 0; //pra qnd limpar ir pra 0
    }

    function adicionarNumero(numero) {
        if (operador === '') {
            operando1 += numero; //para mais de 1 digito, exeplo 50, 60 e 600 e etc
            visor.textContent = operando1;
        } else { //depois do usuario clicar no operador
            operando2 += numero; //aparecera o operador 2
            visor.textContent = operando2;
        }
    }

    function adicionarOperador(op) { //se tirar ele concatena
        operador = op;
    }

    function calcular() {
        if (operando1 !== '' && operando2 !== '' && operador !== '') { //verifica se o 1 o 2 e o oeprador contem valor ou seja se sao diferentes de nada
            switch (operador) {
                case '+':
                    resultado = parseFloat(operando1) + parseFloat(operando2);
                    break;
                case '-':
                    resultado = parseFloat(operando1) - parseFloat(operando2);
                    break;
                case '*':
                    resultado = parseFloat(operando1) * parseFloat(operando2);
                    break;
                case '/':
                    resultado = parseFloat(operando1) / parseFloat(operando2);
                    break;

                case '%':
                    resultado = parseFloat(operando1) * parseFloat(operando2 / 100);
                    break;
                case '√':
                    resultado = Math.sqrt(parseFloat(operando1));
                    break;
            }
            visor.textContent = resultado;
            operando1 = resultado.toString(); //pra nao concaternar com a proxima operação
            operando2 = ''; //a ser definido pra prox operaçao
            operador = ''; //a ser definido pra prox operaçao
        }
    }

    document.querySelectorAll('.botao').forEach(function (botao) { //forEach percorre todos os botoes e add um eventlister de click neles
        botao.addEventListener('click', function () {
            let valor = this.textContent; //o botao(numero) digitado vai armazenar na variavel valor
            if (!isNaN(parseInt(valor))) { //se for diferente de Not a Number armazena em valor
                adicionarNumero(valor);
            } else if (valor === '=') {
                calcular();
            } else if (valor === 'AC') {
                limparVisor();
            } else {
                adicionarOperador(valor); //add o operador ao valor +,-,% e etc
            }
        });
    });
});